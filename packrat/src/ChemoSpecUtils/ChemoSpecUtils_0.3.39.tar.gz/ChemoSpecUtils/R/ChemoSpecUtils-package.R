#'
#' Functions Supporting Packages ChemoSpec and ChemoSpec2D
#'
#' Functions supporting the packages ChemoSpec and ChemoSpec2D.
#' 
#' @name ChemoSpecUtils-package
#' 
#' @aliases ChemoSpecUtils-package ChemoSpecUtils
#' 
#' @docType package
#' 
#' @author Bryan A. Hanson.
#' 
#' Maintainer: Bryan A. Hanson \email{hanson@@depauw.edu}
#' 
NULL


