## Summary



## Checklist

- [ ] I agree to follow the [Code of Conduct][conduct]
- [ ] I have read the [contributing guidelines][contributing]
- [ ] I ran the script [contribute.R][]

[conduct]: https://github.com/jdblischak/workflowr/blob/master/CODE_OF_CONDUCT.md
[contributing]: https://github.com/jdblischak/workflowr/blob/master/CONTRIBUTING.md
[contribute.R]: https://github.com/jdblischak/workflowr/blob/master/contribute.R

## Details

