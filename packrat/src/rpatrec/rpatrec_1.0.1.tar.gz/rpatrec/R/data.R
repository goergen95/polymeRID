#'Daily Closing Prices of major Stock Market Indices
#'
#'The file \code{stockmarket.RData} contains the daily closing prices of the DAX30, Dow Jones Industrials and the Nikkei 225, from January 2000 until December 2016.
#'
#'
"data"
