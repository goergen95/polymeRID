library(testthat)
library(rpatrec)

test_check("rpatrec")
