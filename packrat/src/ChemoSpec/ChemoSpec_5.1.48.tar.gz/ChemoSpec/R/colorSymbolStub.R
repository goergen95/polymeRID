#'
#' Color and Symbols in ChemoSpec and ChemoSpec2D
#' 
#' You can access
#' full documentation via \code{\link[ChemoSpecUtils]{colorSymbol}}.
#'
#' @name colorSymbol
#' 
NULL
